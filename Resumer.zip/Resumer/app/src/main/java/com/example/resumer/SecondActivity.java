package com.example.resumer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        String Name;
        String Email;


        TextView textView = (TextView) findViewById(R.id.textView);
        Name = getIntent().getExtras().getString("NAME");
        Email= getIntent().getExtras().getString("EMAIL");

        textView.setText("Name");
        textView.setText("Email");
        textView.setText("Name:"+" '"+Name+'\n' +"Email:"+" "+Email);
    }
}
